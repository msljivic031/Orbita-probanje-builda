# ORBITA R13AN public encrypted CI bridge

This repository is intended to be PUBLIC, while the ORBITA source stays confidential.

Public contents:
- authenticated AES-256-GCM ciphertext only
- CI workflow
- non-secret manifest

NEVER upload `ORBITA_PUBLIC_CI_SECRET_DO_NOT_UPLOAD.txt`.

Required GitHub Actions repository secret:
- name: `ORBITA_CI_AES256_KEY_B64`
- value is stored only in the local secret file delivered separately to the owner.

Exact plaintext candidate SHA256: `140846e9be04d3da222996fed9701771c4cb1be1c8395e766512ece153ba399a`
Encrypted payload SHA256: `827742a1633bd71dae1d2e1fb3dc77a95835a279a660016c8844d305341b1687`

The workflow decrypts on the Windows runner, authenticates AES-GCM, rechecks the exact plaintext SHA256, then executes the existing ORBITA npm owners: npm ci -> typecheck -> check -> build -> package:win.
